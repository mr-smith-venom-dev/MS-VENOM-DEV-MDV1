const settings = require('../settings');
const isOwnerOrSudo = require('../lib/isOwner');

async function forceJoinCommand(sock, chatId, message, args) {
    try {
        const senderId = message.key.participant || message.key.remoteJid;
        const isOwner = await isOwnerOrSudo(senderId, sock, chatId);

        if (!message.key.fromMe && !isOwner) {
            return await sock.sendMessage(chatId, {
                text: `╔══〘 🚫 *𝓓𝓮𝓷𝓲𝓮𝓭* 〙══╗\n\nOnly the bot owner can use this command.\n\n╚════════════════════════╝`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: { newsletterJid: '120363424596865698@newsletter', newsletterName: '', serverMessageId: -1 }
                }
            }, { quoted: message });
        }

        const link = args && args[0];
        if (!link) {
            return await sock.sendMessage(chatId, {
                text: `╔══〘 🔗 *𝓕𝓸𝓻𝓬𝓮 𝓙𝓸𝓲𝓷* 〙══╗\n\n` +
                      `*Usage:* .forcejoin <group link>\n\n` +
                      `*Example:*\n.forcejoin https://chat.whatsapp.com/XXXX\n\n` +
                      `╚════════════════════════╝`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: { newsletterJid: '120363424596865698@newsletter', newsletterName: '', serverMessageId: -1 }
                }
            }, { quoted: message });
        }

        await sock.sendMessage(chatId, {
            text: `╔══〘 ⏳ *𝓙𝓸𝓲𝓷𝓲𝓷𝓰...* 〙══╗\n\nAttempting to join group...\n\n╚════════════════════════╝`,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: '', newsletterName: '', serverMessageId: -1 }
            }
        }, { quoted: message });

        try {
            const code = link.split('https://chat.whatsapp.com/').pop();
            await sock.groupAcceptInvite(code);

            await sock.sendMessage(chatId, {
                text: `╔══〘 ✅ *𝓙𝓸𝓲𝓷𝓮𝓭!* 〙══╗\n\n✨ Successfully joined the group!\n\n╚════════════════════════╝`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: { newsletterJid: '120363424596865698@newsletter', newsletterName: '', serverMessageId: -1 }
                }
            }, { quoted: message });
        } catch (joinError) {
            console.error('Force join error:', joinError);
            await sock.sendMessage(chatId, {
                text: `╔══〘 ❌ *𝓕𝓪𝓲𝓵𝓮𝓭* 〙══╗\n\nCould not join group.\nCheck the link is valid and not expired.\n\n╚════════════════════════╝`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: { newsletterJid: '1120363424596865698@newsletter', newsletterName: '', serverMessageId: -1 }
                }
            }, { quoted: message });
        }
    } catch (error) {
        console.error('Error in forcejoin command:', error);
        await sock.sendMessage(chatId, {
            text: `╔══〘 ❌ *𝓔𝓻𝓻𝓸𝓻* 〙══╗\n\nAn error occurred. Please try again later.\n\n╚════════════════════════╝`
        }, { quoted: message });
    }
}

module.exports = forceJoinCommand;
