module.exports = {
    name: "andro",
    alias: [".andro"],
    desc: "Andro command",
    category: "misc",
    async run({ sock, m }) {
        await sock.sendMessage(m.chat, { text: "Andro command working ✅" }, { quoted: m });
    }
};
