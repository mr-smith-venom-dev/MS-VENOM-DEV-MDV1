const axios = require('axios');
const { sleep } = require('../lib/myfunc');
async function pairCommand(sock, chatId, message, q) {
    try {
        if (!q) {
            return await sock.sendMessage(chatId, {
                text: `╔══〘 🔗 *┆𝐌|𝐒𒁂VΣ᳄ФM𒀭 ÐΞV⊹𝗠𝗗  𝓟𝓪𝓲𝓻𝓲𝓷𝓰* 〙══╗\n\n` +
                      `Provide your WhatsApp number to get a pairing code.\n\n` +
                      `*Example:* .pair 91702395XXXX\n\n` +
                      `📌 Include country code, no + or spaces\n\n` +
                      `╚════════════════════════╝`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: { newsletterJid: '', newsletterName: '', serverMessageId: -1 }
                }
            }, { quoted: message });
        }

        const numbers = q.split(',')
            .map(v => v.replace(/[^0-9]/g, ''))
            .filter(v => v.length > 5 && v.length < 20);

        if (numbers.length === 0) {
            return await sock.sendMessage(chatId, {
                text: `╔══〘 ❌ *𝓘𝓷𝓿𝓪𝓵𝓲𝓭 𝓝𝓾𝓶𝓫𝓮𝓻* 〙══╗\n\nInvalid number format!\n*Example:* .pair 91702395XXXX\n\n╚════════════════════════╝`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: { newsletterJid: '', newsletterName: '', serverMessageId: -1 }
                }
            }, { quoted: message });
        }

        for (const number of numbers) {
            const whatsappID = number + '@s.whatsapp.net';
            const result = await sock.onWhatsApp(whatsappID);

            if (!result[0]?.exists) {
                return await sock.sendMessage(chatId, {
                    text: `╔══〘 ❌ *𝓝𝓸𝓽 𝓕𝓸𝓾𝓷𝓭* 〙══╗\n\nThat number is not registered on WhatsApp.\nPlease check and try again.\n\n╚════════════════════════╝`,
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: { newsletterJid: '', newsletterName: '', serverMessageId: -1 }
                    }
                }, { quoted: message });
            }

            await sock.sendMessage(chatId, {
                text: `╔══〘 ⏳ *𝓖𝓮𝓷𝓮𝓻𝓪𝓽𝓲𝓷𝓰...* 〙══╗\n\n⚡ Please wait a moment for your pairing code...\n\n╚════════════════════════╝`,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: { newsletterJid: '', newsletterName: '', serverMessageId: -1 }
                }
            }, { quoted: message });

            try {
                const response = await axios.get(`https://knight-bot-paircode.onrender.com/code?number=${number}`);

                if (response.data && response.data.code) {
                    const code = response.data.code;
                    if (code === 'Service Unavailable') throw new Error('Service Unavailable');

                    await sleep(5000);
                    await sock.sendMessage(chatId, {
                        text: `╔══〘 🔑 *𝓟𝓪𝓲𝓻𝓲𝓷𝓰 𝓒𝓸𝓭𝓮* 〙══╗\n\n` +
                              `✅ *Your Code:*\n\n*${code}*\n\n` +
                              `📱 Open WhatsApp → Linked Devices\n` +
                              `→ Link with phone number → Enter code above\n\n` +
                              `╚════════════════════════╝`,
                        contextInfo: {
                            forwardingScore: 1,
                            isForwarded: true,
                            forwardedNewsletterMessageInfo: { newsletterJid: '', newsletterName: '', serverMessageId: -1 }
                        }
                    }, { quoted: message });
                } else {
                    throw new Error('Invalid response from server');
                }
            } catch (apiError) {
                console.error('API Error:', apiError);
                const errMsg = apiError.message === 'Service Unavailable'
                    ? `╔══〘 ⚠️ *𝓢𝓮𝓻𝓿𝓲𝓬𝓮 𝓓𝓸𝔀𝓷* 〙══╗\n\nService unavailable. Please try again later.\n\n╚════════════════════════╝`
                    : `╔══〘 ❌ *𝓔𝓻𝓻𝓸𝓻* 〙══╗\n\nFailed to generate pairing code. Try again later.\n\n╚════════════════════════╝`;

                await sock.sendMessage(chatId, {
                    text: errMsg,
                    contextInfo: {
                        forwardingScore: 1,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: { newsletterJid: '', newsletterName: '', serverMessageId: -1 }
                    }
                }, { quoted: message });
            }
        }
    } catch (error) {
        console.error(error);
        await sock.sendMessage(chatId, {
            text: `╔══〘 ❌ *𝓔𝓻𝓻𝓸𝓻* 〙══╗\n\nAn error occurred. Please try again later.\n\n╚════════════════════════╝`,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: { newsletterJid: '', newsletterName: '', serverMessageId: -1 }
            }
        }, { quoted: message });
    }
}

module.exports = pairCommand;
