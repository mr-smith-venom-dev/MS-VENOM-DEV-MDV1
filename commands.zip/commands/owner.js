const settings = require('../settings');

async function ownerCommand(sock, chatId, message) {
    const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${settings.botOwner}\nTEL;waid=${settings.ownerNumber}:${settings.ownerNumber}\nEND:VCARD`;

    try {
        await sock.sendMessage(chatId, {
            text: `╔══〘 👑 *𝓑𝓸𝓽 𝓞𝔀𝓷𝓮𝓻* 〙══╗\n\n` +
                  `🤖 *Bot:* ┆𝐌|𝐒𒁂VΣ᳄ФM𒀭 ÐΞV⊹𝗠𝗗 \n` +
                  `👤 *Owner:* ${settings.botOwner}\n` +
                  `📞 *Contact below:*\n\n` +
                  `╚════════════════════════╝`,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '',
                    newsletterName: '',
                    serverMessageId: -1
                }
            }
        }, { quoted: message });

        await sock.sendMessage(chatId, {
            contacts: { displayName: settings.botOwner, contacts: [{ vcard }] }
        }, { quoted: message });
    } catch (error) {
        console.error('Error in owner command:', error);
        await sock.sendMessage(chatId, {
            contacts: { displayName: settings.botOwner, contacts: [{ vcard }] }
        }, { quoted: message });
    }
}

module.exports = ownerCommand;
