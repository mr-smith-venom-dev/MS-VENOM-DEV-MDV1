const eightBallResponses = [
    "Smith say_ Yes, definitely!",
    "Smith say_ No way!",
    "Smith say_ Ask again later.",
    "Smith say_ It is certain.",
    "Smith say_ Very doubtful.",
    "Smith say_ Without a doubt.",
    "Smith say_ My reply is no.",
    "Smith say_ Signs point to yes."
];

async function eightBallCommand(sock, chatId, question) {
    if (!question) {
        await sock.sendMessage(chatId, { text: 'Please ask a question!' });
        return;
    }

    const randomResponse = eightBallResponses[Math.floor(Math.random() * eightBallResponses.length)];
    await sock.sendMessage(chatId, { text: `🎱 ${randomResponse}` });
}

module.exports = { eightBallCommand };
