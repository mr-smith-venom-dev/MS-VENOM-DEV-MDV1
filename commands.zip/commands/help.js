const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message, channelLink) {
    const botName = settings.botName || '𒁂VΣ᳄ФM𒀭 ÐΞV⊹𝗠𝗗';
    const version = settings.version || '3.0.6';
    const owner = settings.botOwner || 't.me/Mrsmith_venom'; 
    const channel = channelLink || settings.channelLink || 'https://whatsapp.com/channel/0029VbC6VbVK5cDIYTAVx50Y';

    const helpMessage = `
𒁂VΣ᳄ФM𒀭 ÐΞV⊹𝗠𝗗 —『ᴄᴏᴍᴍᴀɴᴅ ᴄᴇɴᴛᴇʀ 』
━━━━━━━━━━━━━━━━━━━━━
  ⬡ bot name *${botName}*  ⬡
  ◈ ᴠᴇʀꜱɪᴏɴ  ›  *${version}*
  ◈ ᴏᴡɴᴇʀ    ›  *${owner}*
━━━━━━━━━━━━━━━━━━━━━

╭──〔 ཌ 𝐆𝐄𝐍𝐄𝐑𝐀𝐋 𝐌𝐄𝐍𝐔 ད 〕──╮
│  𒆙  .help / .menu
│  𒆙  .ping
│  𒆙  .alive
│  𒆙  .tts ‹ᴛᴇxᴛ›
│  𒆙  .owner
│  𒆙  .joke
│  𒆙  .quote
│  𒆙  .fact
│  𒆙  .weather ‹ᴄɪᴛʏ›
│  𒆙  .news
│  𒆙  .attp ‹ᴛᴇxᴛ›
│  𒆙  .lyrics ‹ꜱᴏɴɢ›
│  𒆙  .8ball ‹ǫᴜᴇꜱᴛɪᴏɴ›
│  𒆙  .groupinfo
│  𒆙  .staff / .admins
│  𒆙  .vv
│  𒆙  .trt ‹ᴛᴇxᴛ› ‹ʟᴀɴɢ›
│  𒆙  .ss ‹ʟɪɴᴋ›
│  𒆙  .jid
│  𒆙  .url
╰───────────────────────╯

╭──〔 ཐི 𝐀𝐃𝐌𝐈𝐍 𝐏𝐀𝐍𝐄𝐋 ཋྀ 〕──╮
│  𒋨  .ban @ᴜꜱᴇʀ
│  𒋨  .promote @ᴜꜱᴇʀ
│  𒋨  .demote @ᴜꜱᴇʀ
│  𒋨  .mute ‹ᴍɪɴᴜᴛᴇꜱ›
│  𒋨  .unmute
│  𒋨  .delete / .del
│  𒋨  .kick @ᴜꜱᴇʀ
│  𒋨  .warnings @ᴜꜱᴇʀ
│  𒋨  .warn @ᴜꜱᴇʀ
│  𒋨  .antilink
│  𒋨  .antibadword
│  𒋨  .clear
│  𒋨  .tag ‹ᴍᴇꜱꜱᴀɢᴇ›
│  𒋨  .tagall
│  𒋨  .tagnotadmin
│  𒋨  .hidetag ‹ᴍᴇꜱꜱᴀɢᴇ›
│  𒋨  .chatbot
│  𒋨  .resetlink
│  𒋨  .antitag ‹ᴏɴ/ᴏꜰꜰ›
│  𒋨  .welcome ‹ᴏɴ/ᴏꜰꜰ›
│  𒋨  .goodbye ‹ᴏɴ/ᴏꜰꜰ›
│  𒋨  .setgdesc ‹ᴅᴇꜱᴄ›
│  𒋨  .setgname ‹ɴᴀᴍᴇ›
│  𒋨  .setgpp ‹ʀᴇᴘʟʏ ɪᴍɢ›
╰────────────────────╯

╭──〔 ☬ 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 ☬ 〕──╮
│  𒄆  .mode ‹ᴘᴜʙʟɪᴄ/ᴘʀɪᴠᴀᴛᴇ›
│  𒄆  .clearsession
│  𒄆  .antidelete
│  𒄆  .cleartmp
│  𒄆  .update
│  𒄆  .settings
│  𒄆  .setpp ‹ʀᴇᴘʟʏ ɪᴍɢ›
│  𒄆  .autoreact ‹ᴏɴ/ᴏꜰꜰ›
│  𒄆  .autostatus ‹ᴏɴ/ᴏꜰꜰ›
│  𒄆  .autotyping ‹ᴏɴ/ᴏꜰꜰ›
│  𒄆  .autoread ‹ᴏɴ/ᴏꜰꜰ›
│  𒄆  .anticall ‹ᴏɴ/ᴏꜰꜰ›
│  𒄆  .pmblocker ‹ᴏɴ/ᴏꜰꜰ›
│  𒄆  .setmention ‹ʀᴇᴘʟʏ›
│  𒄆  .mention ‹ᴏɴ/ᴏꜰꜰ›
╰──────────────────────╯

╭──〔 𖣘 𝐈𝐌𝐀𝐆𝐄 & 𝐒𝐓𝐈𝐂𝐊𝐄𝐑 𖣘 〕──╮
│  𒆜⁩  .blur ‹ɪᴍᴀɢᴇ›
│  𒆜⁩  .simage ‹ꜱᴛɪᴄᴋᴇʀ›
│  𒆜⁩  .sticker ‹ɪᴍᴀɢᴇ›
│  𒆜⁩  .removebg
│  𒆜⁩  .remini
│  𒆜⁩  .crop ‹ɪᴍᴀɢᴇ›
│  𒆜⁩  .tgsticker ‹ʟɪɴᴋ›
│  𒆜⁩  .meme
│  𒆜⁩  .take ‹ᴘᴀᴄᴋɴᴀᴍᴇ›
│  𒆜⁩  .emojimix ‹ᴇ1›+‹ᴇ2›
│  𒆜⁩  .igs ‹ɪɴꜱᴛᴀ ʟɪɴᴋ›
│  𒆜⁩  .igsc ‹ɪɴꜱᴛᴀ ʟɪɴᴋ›
╰─────────────────────────╯

╭──〔 ❒ 𝐆𝐀𝐌𝐄 𝐇𝐔𝐁 ❒ 〕──╮
│  𒀯  .tictactoe @ᴜꜱᴇʀ
│  𒀯  .hangman
│  𒀯  .guess ‹ʟᴇᴛᴛᴇʀ›
│  𒀯  .trivia
│  𒀯  .answer ‹ᴀɴꜱᴡᴇʀ›
│  𒀯  .truth
│  𒀯  .dare
╰───────────────────╯

╭──〔 ꕥ 𝐀𝐈 𝐏𝐎𝐖𝐄𝐑 ꕥ 〕──╮
│  𒁈  .gpt ‹ǫᴜᴇꜱᴛɪᴏɴ›
│  𒁈  .gemini ‹ǫᴜᴇꜱᴛɪᴏɴ›
│  𒁈  .imagine ‹ᴘʀᴏᴍᴘᴛ›
│  𒁈  .flux ‹ᴘʀᴏᴍᴘᴛ›
│  𒁈  .sora ‹ᴘʀᴏᴍᴘᴛ›
╰───────────────────╯

╭──〔 𓇥 𝐅𝐔𝐍 & 𝐒𝐎𝐂𝐈𝐀𝐋 𓇥 〕──╮
│  𒈔  .compliment @ᴜꜱᴇʀ
│  𒈔  .insult @ᴜꜱᴇʀ
│  𒈔  .flirt
│  𒈔  .shayari
│  𒈔  .goodnight
│  𒈔  .roseday
│  𒈔  .character @ᴜꜱᴇʀ
│  𒈔  .wasted @ᴜꜱᴇʀ
│  𒈔  .ship @ᴜꜱᴇʀ
│  𒈔  .simp @ᴜꜱᴇʀ
│  𒈔  .stupid @ᴜꜱᴇʀ
╰──────────────────────╯

╭──〔 ᯾ 𝐌𝐄𝐃𝐈𝐀 & 𝐃𝐎𝐖𝐍𝐋𝐎𝐀𝐃 ᯾ 〕──╮
│  𒇫  .play ‹ꜱᴏɴɢ›
│  𒇫  .song ‹ɴᴀᴍᴇ›
│  𒇫  .video ‹ɴᴀᴍᴇ›
│  𒇫  .spotify ‹ǫᴜᴇʀʏ›
│  𒇫  .tiktok ‹ʟɪɴᴋ›
│  𒇫  .yt ‹ʟɪɴᴋ›
╰───────────────────────────╯

━━━━━━━━━━━━━━━━━━━━━
  𝐌|𝐒𒁂VΣ᳄ФM𒀭 ÐΞV⊹ 𝗠𝗗
━━━━━━━━━━━━━━━━━━━━━`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.png');

        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363424596865698@newsletter',
                        newsletterName: '𒁂VΣ᳄ФM𒀭 ÐΞV⊹𝗠𝗗',
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        } else {
            await sock.sendMessage(chatId, {
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363424596865698@newsletter',
                        newsletterName: '𝐌|𝐒𒁂VΣ᳄ФM𒀭 ÐΞV⊹ 𝗧𝗘𝗖𝗛',
                        serverMessageId: -1
                    }
                }
            }, { quoted: message });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage }, { quoted: message });
    }
}

module.exports = helpCommand;
