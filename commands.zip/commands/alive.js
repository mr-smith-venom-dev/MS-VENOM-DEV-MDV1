const settings = require('../settings');

async function aliveCommand(sock, chatId, message) {
    try {
        const aliveMsg =
            `╔══〘 ✅ *M|S VENOM DEV MD 𝓘𝓼 𝓐𝓵𝓲𝓿𝓮!* 〙══╗\n\n` +
            `🤖 *Bot:* ${settings.botName}\n` +
            `🔖 *Version:* ${settings.version}\n` +
            `⚡ *Status:* Online\n` +
            `🌐 *Mode:* Public\n\n` +
            `┏━━━〘 🌟 *𝓕𝓮𝓪𝓽𝓾𝓻𝓮𝓼* 〙━━━\n` +
            `┃ ⟡ Group Management\n` +
            `┃ ⟡ AI Commands\n` +
            `┃ ⟡ Antilink Protection\n` +
            `┃ ⟡ Fun Commands\n` +
            `┃ ⟡ Media Downloader\n` +
            `┃ ⟡ And much more!\n` +
            `┗━━━━━━━━━━━━━━━━━━━\n\n` +
            `Type *.menu* for the full command list\n\n` +
            `╚════════════════════════╝`;

        await sock.sendMessage(chatId, {
            text: aliveMsg,
            contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: '120363424596865698@newsletter',
                    newsletterName: '',
                    serverMessageId: -1
                }
            }
        }, { quoted: message });
    } catch (error) {
        console.error('Error in alive command:', error);
        await sock.sendMessage(chatId, { text: '✅ M|S VENOM DEV MD is alive and running!' }, { quoted: message });
    }
}

module.exports = aliveCommand;
