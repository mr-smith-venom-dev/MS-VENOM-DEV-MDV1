async function unmuteCommand(sock, chatId) {
    await sock.groupSettingUpdate(chatId, 'not_announcement'); // Unmute the group
    await sock.sendMessage(chatId, { text: 'The group has been unmuted ᴘᴏᴡᴇʀᴇᴅ ʙʏ sᴍɪᴛʜ ʙᴏᴛ.' });
}

module.exports = unmuteCommand;
